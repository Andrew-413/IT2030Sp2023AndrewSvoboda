﻿namespace AndrewBuildsComputers.Models
{
    public class MySession
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set;}
        public string? course { get; set; }
        public int? favNum { get; set;}
    }
}
