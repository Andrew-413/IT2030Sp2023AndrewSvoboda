﻿namespace AndrewBuildsComputers.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel
                {
                    ProductId = 1,
                    ProductName = "Low End Pre-Built Gaming PC",
                    ProductDescription = "The go to PC for those who are on a tight budget but still want to be able to run a plethora of modern games.",
                    ProductImage = "lowend.jpg",
                    ProductPrice = 800
                },
                new ProductModel
                {
                    ProductId = 2,
                    ProductName = "Medium End Pre-Built Gaming PC",
                    ProductDescription = "Find the best bang for your buck with this machine. Medium end specs mean that you can begin to run most modern games at low to medium settings.",
                    ProductImage = "mediumend.jpg",
                    ProductPrice = 1200
                },
                new ProductModel 
                {
                    ProductId = 3,
                    ProductName = "High End Pre-Built Gaming PC",
                    ProductDescription = "Some of the best parts money can buy in todays PC market. You will have no issue running any game at medium to high settings. Happy gaming!",
                    ProductImage = "highend.jpg",
                    ProductPrice = 2000
                },
                new ProductModel
                {
                    ProductId = 4,
                    ProductName = "Basic PC Maintenence",
                    ProductDescription = "The cheapest option for maintaining your PC. Includes a basic hardware and software checkup and cleaning.",
                    ProductImage = "cleaning1.jpg",
                    ProductPrice = 50
                },
                new ProductModel
                {
                    ProductId= 5,
                    ProductName = "Moderate PC Maintenence",
                    ProductDescription = "The middle of the road option for PC fixing and upkeep. Includes cleaning, hardware checkup, as well as software checkup and replacement.",
                    ProductImage = "cleaning2.jpg",
                    ProductPrice = 100
                },
                new ProductModel
                {
                    ProductId= 6,
                    ProductName = "High End PC Maintenence",
                    ProductDescription = "The highest quality and most expensive option for PC upkeep. Includes a thourough cleaning, hardware checkup and replacement, as well as software checkup and replacement.",
                    ProductImage = "cleaning3.jpg",
                    ProductPrice = 200
                }
            };
            return products;
        }
        public static ProductModel GetProduct(int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products)
            {
                if (product.ProductId == id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }
}
