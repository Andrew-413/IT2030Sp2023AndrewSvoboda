﻿using AndrewBuildsComputers.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace AndrewBuildsComputers.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult FAQ()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public ViewResult Tools()
        {
            HttpContext.Session.SetString("FirstName", "Andrew");
            HttpContext.Session.SetString("LastName", "Svoboda");
            HttpContext.Session.SetString("course", "IT2030");
            HttpContext.Session.SetInt32("favNum", 413);
            HttpContext.Session.GetString("FirstName");
            HttpContext.Session.GetString("LastName");
            HttpContext.Session.GetString("course");
            HttpContext.Session.GetInt32("favNum");
            return View();
        }
        /*public ViewResult Tools(string? FirstName, string? LastName, string? course, int? favNum)
        {
            FirstName = HttpContext.Session.GetString("FirstName");
            LastName = HttpContext.Session.GetString("LastName");
            course = HttpContext.Session.GetString("course");
            favNum = HttpContext.Session.GetInt32("favNum");
            return View();
        }
        */
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}