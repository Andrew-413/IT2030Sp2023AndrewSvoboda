﻿using AndrewBuildsComputers.Models;
using Microsoft.AspNetCore.Mvc;

namespace AndrewBuildsComputers.Controllers
{
    public class ContactController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(ContactModel model)
        { 
            return View(model);
        }
    }
}
