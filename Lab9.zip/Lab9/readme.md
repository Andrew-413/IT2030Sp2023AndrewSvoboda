added FAQ page
added session variables
added tools page to display session variables
