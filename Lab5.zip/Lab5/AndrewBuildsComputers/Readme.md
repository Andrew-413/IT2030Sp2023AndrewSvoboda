Inital creation of web app homepage. Includes description of web app and a sample image.
